from logging import Logger


class RenderingError(Exception):
    def __init__(self, logger: Logger, message: str, log_message: str = None):
        if log_message is None:
            log_message = message

        logger.error('An error occurred during rendering. {}'.format(log_message))

        super().__init__(message)
