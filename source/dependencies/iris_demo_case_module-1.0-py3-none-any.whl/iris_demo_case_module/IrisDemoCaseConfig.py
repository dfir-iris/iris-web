from iris_interface.IrisModuleInterface import IrisModuleTypes

module_name = "Demo Case Module"
module_description = "Demonstriert Manual Hooks - zeigt einen Button im Case-Menü"
interface_version = 1.1
module_version = 1.0
module_type = IrisModuleTypes.module_processor
pipeline_support = False
pipeline_info = {}
module_configuration = [
    {
        "param_name": "log_actions",
        "param_human_name": "Aktionen loggen",
        "param_description": "Wenn aktiviert, werden alle Button-Klicks geloggt",
        "default": True,
        "mandatory": True,
        "type": "bool"
    }
]