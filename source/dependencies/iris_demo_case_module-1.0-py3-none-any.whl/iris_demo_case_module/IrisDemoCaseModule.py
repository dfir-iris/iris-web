#!/usr/bin/env python3

from iris_interface.IrisModuleInterface import IrisModuleInterface
import iris_demo_case_module.IrisDemoCaseConfig as interface_conf
from iris_interface.IrisInterfaceStatus import IrisInterfaceStatus as IStatus


class IrisDemoCaseModule(IrisModuleInterface):
    _module_name = interface_conf.module_name
    _module_description = interface_conf.module_description
    _interface_version = interface_conf.interface_version
    _module_version = interface_conf.module_version
    _pipeline_support = interface_conf.pipeline_support
    _pipeline_info = interface_conf.pipeline_info
    _module_configuration = interface_conf.module_configuration
    _module_type = interface_conf.module_type

    def register_hooks(self, module_id: int):
        status = self.register_to_hook(
            module_id=module_id,
            iris_hook_name='on_manual_trigger_case',
            manual_hook_name='Demo Aktion ausführen'
        )

        if status.is_failure():
            self.log.error(f"Hook-Registrierung fehlgeschlagen: {status.get_message()}")
        else:
            self.log.info("Erfolgreich subscribed zu on_manual_trigger_case")

    def hooks_handler(self, hook_name: str, hook_ui_name: str, data):
        if self._dict_conf.get('log_actions') is True:
            self.log.info(f"Manual Hook ausgelöst: {hook_name}")
            self.log.info(f"UI Name: {hook_ui_name}")
            self.log.info(f"Empfangene Daten: {data}")

            if data and len(data) > 0:
                case = data[0]
                if hasattr(case, 'case_name'):
                    self.log.info(f"Case-Name: {case.case_name}")
                if hasattr(case, 'case_id'):
                    self.log.info(f"Case-ID: {case.case_id}")

        return IStatus.I2Success(
            data=data,
            logs=list(self.message_queue)
        )