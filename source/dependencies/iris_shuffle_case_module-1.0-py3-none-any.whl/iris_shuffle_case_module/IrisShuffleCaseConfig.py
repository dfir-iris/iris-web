from iris_interface.IrisModuleInterface import IrisModuleTypes

module_name = "Shuffle Case Module"
module_description = "Sendet Case-Daten an einen Shuffle Webhook"
interface_version = 1.1
module_version = 1.0
module_type = IrisModuleTypes.module_processor
pipeline_support = False
pipeline_info = {}
default_webhook_url = "https://shu.zeus:32443/api/v1/hooks/webhook_a56481de-5e87-4ff1-a219-da38b608021a"

module_configuration = [
    {
        "param_name": "webhook_url",
        "param_human_name": "Webhook URL",
        "param_description": "URL des Shuffle Webhooks",
        "default": default_webhook_url,
        "mandatory": True,
        "type": "string"
    },
    {
        "param_name": "send_iocs",
        "param_human_name": "IOCs senden",
        "param_description": "IOCs des Cases an Shuffle senden",
        "default": True,
        "mandatory": True,
        "type": "bool"
    },
    {
        "param_name": "send_assets",
        "param_human_name": "Assets senden",
        "param_description": "Assets des Cases an Shuffle senden",
        "default": False,
        "mandatory": True,
        "type": "bool"
    }
]