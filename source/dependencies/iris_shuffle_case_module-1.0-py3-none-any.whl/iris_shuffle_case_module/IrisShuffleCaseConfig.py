import os
from iris_interface.IrisModuleInterface import IrisModuleTypes

module_name = "Shuffle Case Module"
module_description = "Sendet Case-Daten an einen Shuffle Webhook"
interface_version = 1.1
module_version = 1.0
module_type = IrisModuleTypes.module_processor
pipeline_support = False
pipeline_info = {}
default_webhook_url = os.environ.get('SHUFFLE_WEBHOOK_URL', 'http://shuffle.webhook.local')

module_configuration = [
    {
        "param_name": "webhook_url",
        "param_human_name": "Webhook URL",
        "param_description": "URL des Shuffle Webhooks",
        "default": default_webhook_url,
        "mandatory": True,
        "type": "string"
    },
    {
        "param_name": "send_case_id",
        "param_human_name": "Case-ID senden",
        "param_description": "Case-ID an Shuffle senden",
        "default": True,
        "mandatory": True,
        "type": "bool"
    },
    {
        "param_name": "send_case_name",
        "param_human_name": "Case-Name senden",
        "param_description": "Case-Name an Shuffle senden",
        "default": True,
        "mandatory": True,
        "type": "bool"
    },
    {
        "param_name": "add_note",
        "param_human_name": "Notiz erstellen",
        "param_description": "Notiz im Case mit Log-Eintrag erstellen",
        "default": True,
        "mandatory": True,
        "type": "bool"
    },
    {
        "param_name": "server_url",
        "param_human_name": "IRIS Server URL",
        "param_description": "URL der IRIS Instanz (z.B. http://localhost:8000)",
        "default": "",
        "mandatory": False,
        "type": "string"
    },
    {
        "param_name": "api_key",
        "param_human_name": "IRIS API Key",
        "param_description": "API Key für IRIS",
        "default": "",
        "mandatory": False,
        "type": "string"
    }
]