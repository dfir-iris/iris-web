#!/usr/bin/env python3

import os
import uuid
import datetime
import requests
from iris_interface.IrisModuleInterface import IrisModuleInterface
import iris_interface.IrisInterfaceStatus as IStatus
import iris_shuffle_case_module.IrisShuffleCaseConfig as interface_conf


def safe_value(val):
    if val is None:
        return None
    if isinstance(val, uuid.UUID):
        return str(val)
    if hasattr(val, 'isoformat'):
        return val.isoformat()
    return val


class IrisShuffleCaseModule(IrisModuleInterface):
    _module_name = interface_conf.module_name
    _module_description = interface_conf.module_description
    _interface_version = interface_conf.interface_version
    _module_version = interface_conf.module_version
    _pipeline_support = interface_conf.pipeline_support
    _pipeline_info = interface_conf.pipeline_info
    _module_configuration = interface_conf.module_configuration
    _module_type = interface_conf.module_type

    def register_hooks(self, module_id: int):
        status = self.register_to_hook(
            module_id=module_id,
            iris_hook_name='on_manual_trigger_case',
            manual_hook_name='Create OTRS Ticket'
        )

        if status.is_failure():
            self.log.error(f"Hook-Registrierung fehlgeschlagen: {status.get_message()}")
        else:
            self.log.info("Erfolgreich subscribed zu on_manual_trigger_case")

    def _add_case_note(self, case_id: int, note_title: str, note_content: str, directory_id: int = None):
        try:
            server_url = self._dict_conf.get('server_url')
            api_key = self._dict_conf.get('api_key')
            
            if not server_url or not api_key:
                self.log.warning("Server URL oder API Key nicht konfiguriert. Keine Notiz wird erstellt.")
                return False
            
            note_data = {
                'note_title': note_title,
                'note_content': note_content,
                'directory_id': directory_id
            }
            
            headers = {
                'Authorization': f'Bearer {api_key}',
                'Content-Type': 'application/json'
            }
            
            response = requests.post(
                f"{server_url}/case/notes/add",
                json=note_data,
                headers=headers,
                timeout=30,
                verify=False
            )
            
            if response.status_code in (200, 201):
                self.log.info(f"Notiz '{note_title}' erfolgreich erstellt")
                return True
            else:
                self.log.warning(f"Fehler beim Erstellen der Notiz: {response.status_code} - {response.text[:100]}")
                return False
                
        except Exception as e:
            self.log.warning(f"Fehler beim Erstellen der Notiz: {str(e)}")
            return False

    def hooks_handler(self, hook_name: str, hook_ui_name: str, data):
        self.log.info(f"Manual Hook ausgelöst: {hook_name}")
        self.log.info(f"UI Name: {hook_ui_name}")

        webhook_url = os.environ.get('SHUFFLE_WEBHOOK_URL') or self._dict_conf.get('webhook_url', interface_conf.default_webhook_url)
        send_case_id = self._dict_conf.get('send_case_id', True)
        send_case_name = self._dict_conf.get('send_case_name', True)
        add_note = self._dict_conf.get('add_note', True)

        if data and len(data) > 0:
            case = data[0]
            
            case_id = safe_value(getattr(case, 'case_id', None))
            case_name = safe_value(getattr(case, 'case_name', None)) or safe_value(getattr(case, 'case_title', None)) or safe_value(getattr(case, 'name', None))
            
            case_data = {}
            
            if send_case_id:
                case_data['case_id'] = case_id
                case_data['case_uuid'] = safe_value(getattr(case, 'case_uuid', None))
            
            if send_case_name:
                case_data['case_name'] = case_name

            try:
                self.log.info(f"Sende Request an Shuffle Webhook: {webhook_url}")
                timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                response = requests.post(
                    webhook_url,
                    json=case_data,
                    timeout=30,
                    verify=False
                )
                self.log.info(f"Shuffle Response: {response.status_code} - {response.text[:200]}")
                
                if response.status_code in (200, 201, 202):
                    response_data = response.json() if response.text else {}
                    execution_id = response_data.get('execution_id', 'N/A')
                    
                    note_title = f"Shuffle Webhook - {timestamp}"
                    note_content = f"""## Shuffle Webhook Aufruf

**Zeitpunkt:** {timestamp}
**Case:** {case_name} (ID: {case_id})
**Webhook URL:** {webhook_url}
**Status:** Erfolgreich (HTTP {response.status_code})
**Execution ID:** {execution_id}

**Gesendete Daten:**
```json
{response_data}
```
"""
                    if add_note:
                        self._add_case_note(case_id, note_title, note_content)
                    
                    return IStatus.I2Success(
                        data=data,
                        logs=list(self.message_queue)
                    )
                else:
                    note_title = f"Shuffle Webhook FEHLGESCHLAGEN - {timestamp}"
                    note_content = f"""## Shuffle Webhook Aufruf - FEHLER

**Zeitpunkt:** {timestamp}
**Case:** {case_name} (ID: {case_id})
**Webhook URL:** {webhook_url}
**Status:** Fehlgeschlagen (HTTP {response.status_code})

**Response:**
```
{response.text[:500]}
```
"""
                    if add_note:
                        self._add_case_note(case_id, note_title, note_content)
                    
                    return IStatus.I2Error(
                        message=f"Shuffle Webhook Fehler: {response.status_code}",
                        logs=list(self.message_queue)
                    )
                    
            except requests.exceptions.RequestException as e:
                error_msg = f"Verbindungsfehler zu Shuffle: {str(e)}"
                self.log.error(error_msg)
                
                timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                note_title = f"Shuffle Webhook FEHLER - {timestamp}"
                note_content = f"""## Shuffle Webhook Aufruf - FEHLER

**Zeitpunkt:** {timestamp}
**Case:** {case_name} (ID: {case_id})
**Webhook URL:** {webhook_url}
**Status:** Verbindungsfehler

**Fehlermeldung:**
```
{error_msg}
```
"""
                if add_note:
                    self._add_case_note(case_id, note_title, note_content)
                
                return IStatus.I2Error(
                    message=error_msg,
                    logs=list(self.message_queue)
                )

        return IStatus.I2Error(
            message="Keine Case-Daten empfangen",
            logs=list(self.message_queue)
        )