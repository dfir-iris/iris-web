#!/usr/bin/env python3

import requests
from iris_interface.IrisModuleInterface import IrisModuleInterface
import iris_interface.IrisInterfaceStatus as IStatus
import iris_shuffle_case_module.IrisShuffleCaseConfig as interface_conf


class IrisShuffleCaseModule(IrisModuleInterface):
    _module_name = interface_conf.module_name
    _module_description = interface_conf.module_description
    _interface_version = interface_conf.interface_version
    _module_version = interface_conf.module_version
    _pipeline_support = interface_conf.pipeline_support
    _pipeline_info = interface_conf.pipeline_info
    _module_configuration = interface_conf.module_configuration
    _module_type = interface_conf.module_type

    def register_hooks(self, module_id: int):
        status = self.register_to_hook(
            module_id=module_id,
            iris_hook_name='on_manual_trigger_case',
            manual_hook_name='An Shuffle senden'
        )

        if status.is_failure():
            self.log.error(f"Hook-Registrierung fehlgeschlagen: {status.get_message()}")
        else:
            self.log.info("Erfolgreich subscribed zu on_manual_trigger_case")

    def hooks_handler(self, hook_name: str, hook_ui_name: str, data):
        self.log.info(f"Manual Hook ausgelöst: {hook_name}")
        self.log.info(f"UI Name: {hook_ui_name}")

        webhook_url = self._dict_conf.get('webhook_url', interface_conf.default_webhook_url)
        send_iocs = self._dict_conf.get('send_iocs', True)
        send_assets = self._dict_conf.get('send_assets', False)

        if data and len(data) > 0:
            case = data[0]
            
            case_data = {
                'case_id': getattr(case, 'case_id', None),
                'case_name': getattr(case, 'case_name', None),
                'case_description': getattr(case, 'case_description', None),
                'case_customer': getattr(case, 'case_customer', None),
                'case_soc_id': getattr(case, 'case_soc_id', None),
                'case_uuid': getattr(case, 'case_uuid', None),
                'case_open_date': str(getattr(case, 'case_open_date', '')),
                'case_close_date': str(getattr(case, 'case_close_date', '')),
                'case_state': getattr(case, 'case_state', None),
            }

            if send_iocs and hasattr(case, 'case_iocs'):
                case_data['iocs'] = []
                for ioc in case.case_iocs:
                    case_data['iocs'].append({
                        'ioc_id': getattr(ioc, 'ioc_id', None),
                        'ioc_type': getattr(ioc, 'ioc_type', None),
                        'ioc_value': getattr(ioc, 'ioc_value', None),
                        'ioc_description': getattr(ioc, 'ioc_description', None),
                        'ioc_tlp': getattr(ioc, 'ioc_tlp', None),
                    })

            if send_assets and hasattr(case, 'case_assets'):
                case_data['assets'] = []
                for asset in case.case_assets:
                    case_data['assets'].append({
                        'asset_id': getattr(asset, 'asset_id', None),
                        'asset_name': getattr(asset, 'asset_name', None),
                        'asset_type': getattr(asset, 'asset_type', None),
                        'asset_description': getattr(asset, 'asset_description', None),
                        'asset_ip': getattr(asset, 'asset_ip', None),
                        'asset_domain': getattr(asset, 'asset_domain', None),
                    })

            try:
                self.log.info(f"Sende Request an Shuffle Webhook: {webhook_url}")
                response = requests.post(
                    webhook_url,
                    json=case_data,
                    timeout=30,
                    verify=False
                )
                self.log.info(f"Shuffle Response: {response.status_code} - {response.text[:200]}")
                
                if response.status_code in (200, 201, 202):
                    return IStatus.I2Success(
                        data=data,
                        logs=list(self.message_queue)
                    )
                else:
                    return IStatus.I2Error(
                        message=f"Shuffle Webhook Fehler: {response.status_code}",
                        logs=list(self.message_queue)
                    )
                    
            except requests.exceptions.RequestException as e:
                error_msg = f"Verbindungsfehler zu Shuffle: {str(e)}"
                self.log.error(error_msg)
                return IStatus.I2Error(
                    message=error_msg,
                    logs=list(self.message_queue)
                )

        return IStatus.I2Error(
            message="Keine Case-Daten empfangen",
            logs=list(self.message_queue)
        )