#!/usr/bin/env python3

import uuid
import requests
from iris_interface.IrisModuleInterface import IrisModuleInterface
import iris_interface.IrisInterfaceStatus as IStatus
import iris_shuffle_case_module.IrisShuffleCaseConfig as interface_conf


def safe_value(val):
    if val is None:
        return None
    if isinstance(val, uuid.UUID):
        return str(val)
    if hasattr(val, 'isoformat'):
        return val.isoformat()
    return val


class IrisShuffleCaseModule(IrisModuleInterface):
    _module_name = interface_conf.module_name
    _module_description = interface_conf.module_description
    _interface_version = interface_conf.interface_version
    _module_version = interface_conf.module_version
    _pipeline_support = interface_conf.pipeline_support
    _pipeline_info = interface_conf.pipeline_info
    _module_configuration = interface_conf.module_configuration
    _module_type = interface_conf.module_type

    def register_hooks(self, module_id: int):
        status = self.register_to_hook(
            module_id=module_id,
            iris_hook_name='on_manual_trigger_case',
            manual_hook_name='An Shuffle senden'
        )

        if status.is_failure():
            self.log.error(f"Hook-Registrierung fehlgeschlagen: {status.get_message()}")
        else:
            self.log.info("Erfolgreich subscribed zu on_manual_trigger_case")

    def hooks_handler(self, hook_name: str, hook_ui_name: str, data):
        self.log.info(f"Manual Hook ausgelöst: {hook_name}")
        self.log.info(f"UI Name: {hook_ui_name}")

        webhook_url = self._dict_conf.get('webhook_url', interface_conf.default_webhook_url)
        send_case_id = self._dict_conf.get('send_case_id', True)
        send_case_name = self._dict_conf.get('send_case_name', True)

        if data and len(data) > 0:
            case = data[0]
            
            case_data = {}
            
            if send_case_id:
                case_data['case_id'] = safe_value(getattr(case, 'case_id', None))
                case_data['case_uuid'] = safe_value(getattr(case, 'case_uuid', None))
            
            if send_case_name:
                case_name = (safe_value(getattr(case, 'case_name', None)) or 
                             safe_value(getattr(case, 'case_title', None)) or
                             safe_value(getattr(case, 'name', None)))
                case_data['case_name'] = case_name

            try:
                self.log.info(f"Sende Request an Shuffle Webhook: {webhook_url}")
                response = requests.post(
                    webhook_url,
                    json=case_data,
                    timeout=30,
                    verify=False
                )
                self.log.info(f"Shuffle Response: {response.status_code} - {response.text[:200]}")
                
                if response.status_code in (200, 201, 202):
                    return IStatus.I2Success(
                        data=data,
                        logs=list(self.message_queue)
                    )
                else:
                    return IStatus.I2Error(
                        message=f"Shuffle Webhook Fehler: {response.status_code}",
                        logs=list(self.message_queue)
                    )
                    
            except requests.exceptions.RequestException as e:
                error_msg = f"Verbindungsfehler zu Shuffle: {str(e)}"
                self.log.error(error_msg)
                return IStatus.I2Error(
                    message=error_msg,
                    logs=list(self.message_queue)
                )

        return IStatus.I2Error(
            message="Keine Case-Daten empfangen",
            logs=list(self.message_queue)
        )